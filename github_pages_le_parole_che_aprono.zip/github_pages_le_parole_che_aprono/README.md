# Le parole che aprono — pagina GitHub Pages

Questa cartella contiene una pagina pubblica con modulo Nome, Cognome ed Email.
Il modulo inoltra i dati a `b.ferrari@latitude41.it` tramite FormSubmit e, dopo
l'invio, apre il PDF presente nella stessa repository.

## Pubblicazione su GitHub Pages

1. Crea una repository pubblica chiamata `le-parole-che-aprono` nell'account
   `b.ferrari1106-stack`.
2. Carica nella radice della repository:
   - `index.html`
   - `le_parole_che_aprono_negoziazione_strategica_con_link.pdf`
3. Vai in **Settings → Pages**.
4. In **Build and deployment**, scegli **Deploy from a branch**.
5. Seleziona il branch `main` e la cartella `/ (root)`, poi salva.
6. Attendi la pubblicazione. L'indirizzo previsto è:
   `https://b.ferrari1106-stack.github.io/le-parole-che-aprono/`

## Prima attivazione FormSubmit

Al primo invio del modulo FormSubmit può inviare una richiesta di conferma a
`b.ferrari@latitude41.it`. Clicca il link ricevuto: dopo questa conferma il
modulo potrà inoltrare le richieste successive.

Se scegli un nome diverso da `le-parole-che-aprono` per la repository, modifica
il valore del campo nascosto `_next` dentro `index.html`, sostituendo il nome
della repository nell'URL GitHub Pages.

## Privacy

Il modulo invia i dati a un servizio esterno (FormSubmit) e all'indirizzo
indicato sopra. Prima della pubblicazione definitiva, aggiorna il testo del
consenso e aggiungi il collegamento alla tua informativa privacy, se disponibile.
